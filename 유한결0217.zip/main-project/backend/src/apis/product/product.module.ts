import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Allergy } from '../allergy/entities/allergy.entity';
import { ProductSubCategory } from '../subCategory/entities/productSubCategory.entity';
import { Product } from './entities/product.entity';
import { ProductResolver } from './product.resolver';
import { ProductService } from './product.service';

@Module({
  imports: [TypeOrmModule.forFeature([Product, ProductSubCategory, Allergy])],
  providers: [
    ProductResolver, //
    ProductService,
  ],
})
export class ProductModule {}
