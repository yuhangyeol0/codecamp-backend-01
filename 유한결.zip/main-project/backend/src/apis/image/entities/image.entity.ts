import { Field, ObjectType } from '@nestjs/graphql';
import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm';

@Entity()
@ObjectType()
export class Image {
  @PrimaryGeneratedColumn('uuid')
  @Field(() => String)
  image_id: string;

  @Column()
  @Field(() => String,{nullable:true})
  url?: string;

  @Column()
  @Field(() => Boolean,{nullable:true})
  isImage?: boolean;
}
