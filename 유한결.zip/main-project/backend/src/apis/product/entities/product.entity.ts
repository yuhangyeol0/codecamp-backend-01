import { Field, ObjectType } from '@nestjs/graphql';
import { Allergy } from 'src/apis/allergy/entities/allergy.entity';
import { Image } from 'src/apis/image/entities/image.entity';
import { Size } from 'src/apis/size/entities/size.entity';
import { ProductSubCategory } from 'src/apis/subCategory/entities/productSubCategory.entity';
import {
  Column,
  Entity,
  JoinColumn,
  JoinTable,
  ManyToMany,
  ManyToOne,
  OneToOne,
  PrimaryGeneratedColumn,
} from 'typeorm';

@Entity()
@ObjectType()
export class Product {
  @PrimaryGeneratedColumn('uuid')
  @Field(() => String)
  product_id: string;

  @Column()
  @Field(() => String, { nullable: false })
  name!: string;

  @Column()
  @Field(() => String, { nullable: true })
  description?: string;

  @JoinTable() //상품테이블이 메인이라 여기에 조인함
  @ManyToMany(() => Allergy, (allergy) => allergy.products) //서로 지정 productTag.entity랑 다대다관계임
  @Field(() => [Allergy])
  allergys: Allergy[];

  @JoinTable()
  @ManyToMany(() => Size, (size) => size.products, {
    cascade: true,
    onDelete: 'CASCADE',
  })
  @Field(() => [Size])
  sizes: Size[];

  @JoinColumn()
  @OneToOne(() => Image)
  @Field(() => Image, { nullable: true })
  image?: Image;

  @JoinColumn()
  @ManyToOne(() => ProductSubCategory, { cascade: true, onDelete: 'CASCADE' })
  @Field(() => ProductSubCategory)
  productSubCategory: ProductSubCategory;
}
