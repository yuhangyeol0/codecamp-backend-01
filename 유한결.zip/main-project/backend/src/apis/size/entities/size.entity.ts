import { Field, Int, ObjectType } from '@nestjs/graphql';
import { Material } from 'src/apis/material/entities/material.entity';
import { Product } from 'src/apis/product/entities/product.entity';
import {
  Column,
  Entity,
  JoinColumn,
  ManyToMany,
  OneToOne,
  PrimaryGeneratedColumn,
} from 'typeorm';

@Entity()
@ObjectType()
export class Size {
  @PrimaryGeneratedColumn('uuid')
  @Field(() => String)
  size_id: string;

  @Column()
  @Field(() => String,{nullable:false})
  name!: string;

  @Column()
  @Field(() => Int,{nullable:true})
  amount?: number;

  @ManyToMany(() => Product, (product) => product.sizes)
  @Field(() => [Product])
  products: Product[];

  @JoinColumn()
  @OneToOne(() => Material)
  @Field(() => Material)
  material: Material;
}
