import { Strategy, ExtractJwt } from 'passport-jwt';
import { PassportStrategy } from '@nestjs/passport';
import { Injectable } from '@nestjs/common';

@Injectable()
export class JwtRefreshStrategy extends PassportStrategy(Strategy, 'refresh') {
  constructor() {
    super({
      jwtFromRequest: (req)=>{
        const cookies = req.headers.cookies
        return cookies.replace('refreshToken=','')
      },
      secretOrKey: 'myRefreshKey',
    });
  }
  //검증끝나고 수행되는 부분
  validate(payload) {
    console.log(payload);
    return {
      id: payload.sub,
      email: payload.email,
    }; 
  }
}
