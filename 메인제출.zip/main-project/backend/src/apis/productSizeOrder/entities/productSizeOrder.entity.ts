import { Field, ObjectType } from "@nestjs/graphql";
import { Cart } from "src/apis/cart/entities/cart.entity";
import { Order } from "src/apis/order/entities/order.entity";
import { Product_Size } from "src/apis/productSize/entities/productSize.entity";
import { Entity, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from "typeorm";


@Entity()
@ObjectType()
export class ProductSizeOrder{
    @PrimaryGeneratedColumn('uuid')
    @JoinColumn()
    @ManyToOne(()=>Product_Size)
    @Field(()=>Product_Size)
    product_id:Product_Size

    @JoinColumn()
    @ManyToOne(()=>Product_Size)
    @Field(()=>Product_Size)
    size_id:Product_Size

    @JoinColumn()
    @ManyToOne(()=>Cart)
    @Field(()=>Cart)
    cart_id:Cart

    @JoinColumn()
    @ManyToOne(()=>Order)
    @Field(()=>Order)
    order_id:Order
}