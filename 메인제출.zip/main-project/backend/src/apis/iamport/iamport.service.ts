import { ConflictException, Injectable, UnprocessableEntityException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import axios from 'axios';
import { CurrentUser } from 'src/common/auth/gql-user.param';
import { Repository } from 'typeorm';
import {Payment} from '../payment/entities/payment.entity'
import {PAYMENT_STATUS_ENUM} from '../payment/entities/payment.entity'
import { PointTransaction, POINT_TRANSACTION_STATUS_ENUM } from '../pointTransaction/entities/pointTransaction.entity';
import { PointTransactionService } from '../pointTransaction/pointTransaction.service';
import {User} from '../user/entities/user.entity'

@Injectable()
export class ImportService {
  constructor(   
    @InjectRepository(PointTransaction)
    private readonly pointTransactionRepository: Repository<PointTransaction>, 
    @InjectRepository(User)          
    private readonly userRepository:Repository<User>){}

  async iamportService( {impUid}) {
    // if(this.payment.status=== PAYMENT_STATUS_ENUM.COMPLETE){
    //   throw "결제된 상품입니다"
    // }
    const user = this.userRepository.findOne(impUid)
    console.log(user)
    if(user){ throw new ConflictException}

    const getToken = await axios.post("https://api.iamport.kr/users/getToken",
      {
        imp_key: '3711259373293770', // REST API키
        imp_secret:'f8210901b4e0d19fe07589b8ed6d8562d997c8729b6d0ca73a6da4485db95943140f89a2834d0e60', // REST API Secret
      },
    );
    const { access_token } = getToken.data.response;
  try{
    const getPaymentData = await axios.get(
       `https://api.iamport.kr/payments/${impUid}`,
      {
        headers: {"Authorization": access_token}
      }, // 발행된 액세스 토큰
    );
    const paymentData = getPaymentData.data.response;
  }
  catch(idError){
    throw new UnprocessableEntityException
  }
  }
  async CancelPayment({impUid}){
    const istoken = await this.pointTransactionRepository.findOne({ impUid });
    const { status, createdAt, id, amount, ...rest } = istoken;

    const getToken = await axios.post("https://api.iamport.kr/users/getToken",
      {
        imp_key: '3711259373293770', 
        imp_secret:'f8210901b4e0d19fe07589b8ed6d8562d997c8729b6d0ca73a6da4485db95943140f89a2834d0e60', // REST API Secret
      },
    );
    const { access_token } = getToken.data.response;
    const getCancelData = await axios.post(`https://api.iamport.kr/payments/cancel`,
    {
      headers: {"Authorization": access_token}
    },
    )
    const pointTransaction = await this.pointTransactionRepository.create({
      impUid: impUid,
      amount: -amount,
      status: POINT_TRANSACTION_STATUS_ENUM.PAYMENT,
    }); 
    return await this.pointTransactionRepository.save(pointTransaction);
  }    
}