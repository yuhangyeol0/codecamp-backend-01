import { Field, Int, ObjectType, registerEnumType } from '@nestjs/graphql';
import { Product } from 'src/apis/product/entities/product.entity';
import { Size } from 'src/apis/size/entities/size.entity';
import {
  Column,
  CreateDateColumn,
  Entity,
  JoinTable,
  ManyToMany,
  ManyToOne,
  PrimaryGeneratedColumn,
} from 'typeorm';

export enum PAYMENT_STATUS_ENUM {
  PAYMENT = 'PAYMENT',
  READY = 'READY',
  COMPLETE = 'COMPLETE',
}

registerEnumType(PAYMENT_STATUS_ENUM, {
  name: 'PAYMENT_STATUS_ENUM',
});
@Entity()
@ObjectType()
export class Payment {
  @PrimaryGeneratedColumn('uuid')
  @Field()
  payment_id: string;

  @JoinTable()
  @ManyToMany(() => Product, (products) => products.payments)
  @Field(() => [Product])
  products: Product[];

  @JoinTable()
  @ManyToMany(() => Size, (sizes) => sizes.payments)
  @Field(() => [Size])
  sizes: Size[];

  @Column()
  @Field(() => Int)
  quantity: number;

  @Column({ type: 'enum', enum: PAYMENT_STATUS_ENUM })
  @Field(() => PAYMENT_STATUS_ENUM)
  status: PAYMENT_STATUS_ENUM;

  @Column()
  @Field(() => Int)
  amount: number;

  @CreateDateColumn()
  createdAt: Date;
}
