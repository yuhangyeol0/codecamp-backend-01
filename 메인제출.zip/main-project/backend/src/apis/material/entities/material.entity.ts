import { Field, Int, ObjectType } from '@nestjs/graphql';
import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm';

@Entity()
@ObjectType()
export class Material {
  @PrimaryGeneratedColumn('uuid')
  @Field(() => String)
  material_id: string;

  @Column()
  @Field(() => Int,{nullable:true})
  kcal?: number;

  @Column()
  @Field(() => Int,{nullable:true})
  sweet?: number;

  @Column()
  @Field(() => Int,{nullable:true})
  protein?: number;

  @Column()
  @Field(() => Int,{nullable:true})
  fat?: number;

  @Column()
  @Field(() => Int,{nullable:true})
  caffein?: number;

  @Column()
  @Field(() => Int,{nullable:false})
  price!: number;
}
