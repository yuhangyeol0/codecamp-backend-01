import { Field, Int, ObjectType } from '@nestjs/graphql';
import { Material } from 'src/apis/material/entities/material.entity';
import { Payment } from 'src/apis/payment/entities/payment.entity';
import {
  Column,
  Entity,
  JoinColumn,
  ManyToMany,
  OneToOne,
  PrimaryGeneratedColumn,
} from 'typeorm';

@Entity()
@ObjectType()
export class Size {
  @PrimaryGeneratedColumn('uuid')
  @Field(() => String)
  size_id: string;

  @Column()
  @Field(() => String,{nullable:false})
  name!: string;

  @Column()
  @Field(() => Int,{nullable:true})
  amount?: number;

  @JoinColumn()
  @OneToOne(() => Material)
  @Field(() => Material)
  material: Material;

  @ManyToMany(()=>Payment, (payment)=>payment.sizes)
  @Field(()=>[Payment])
  payments:Payment[]
}
