import { Field, ObjectType } from "@nestjs/graphql";
import { Product } from "src/apis/product/entities/product.entity";
import { Size } from "src/apis/size/entities/size.entity";
import { Entity, JoinColumn, JoinTable, ManyToMany, ManyToOne, PrimaryGeneratedColumn } from "typeorm";

@Entity()
@ObjectType()
export class Product_Size{
    @PrimaryGeneratedColumn('uuid')
    @JoinColumn()
    @ManyToOne(()=>Product)
    @Field(()=>Product)
    prodict_id:Product

    @JoinColumn()
    @ManyToOne(()=>Size)
    @Field(()=>Size)
    size_id:Size

    
}