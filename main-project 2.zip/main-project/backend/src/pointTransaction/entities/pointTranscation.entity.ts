import { Field, Int, registerEnumType } from '@nestjs/graphql';
import { Column, CreateDateColumn, PrimaryGeneratedColumn } from 'typeorm';

export enum POINT_TRANSCSACTION_STATUS_ENUM {
  PAYMENT = 'PAYMENT',
  CANCEL = 'CANCLE',
}

registerEnumType(POINT_TRANSCSACTION_STATUS_ENUM, {
  name: 'POINT_TRANSACTION_STATUS_ENUM',
});

export class pointTransaction {
  @PrimaryGeneratedColumn('uuid')
  @Field(() => String)
  id: string;

  @Column()
  @Field(() => String)
  imUid: string;

  @Column()
  @Field(() => Int)
  amount: number;

  @Column({ type: 'enum', enum: POINT_TRANSCSACTION_STATUS_ENUM })
  @Field(() => POINT_TRANSCSACTION_STATUS_ENUM)
  status: POINT_TRANSCSACTION_STATUS_ENUM;

  @CreateDateColumn()
  @Field(() => Date)
  createdAt: Date;
}
