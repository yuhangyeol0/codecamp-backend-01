import { Resolver } from '@nestjs/graphql';

@Resolver()
export class PaymentResolver {
  //1. 상품
}
