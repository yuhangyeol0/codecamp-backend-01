import { PrimaryGeneratedColumn, Column, Entity, ManyToOne } from 'typeorm';
import { Product } from 'src/apis/product/entities/product.entity';

@Entity()
export class Image {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  URL: string;

  @Column()
  isImage: boolean;

  @ManyToOne(() => Product)
  product: Product;
}
