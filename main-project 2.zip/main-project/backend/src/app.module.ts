import { Module } from '@nestjs/common';
// import { AppController } from './app.controller';
// import { AppService } from './app.service';
// import { ConfigModule } from '@nestjs/config';
import { GraphQLModule, GqlModuleOptions } from '@nestjs/graphql';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AuthModule } from './apis/auth/auth.module';
import { ApolloDriver } from '@nestjs/apollo';
import { ProductModule } from './apis/product/product.module';
import { SubCategoryModule } from './apis/subCategory/subCategory.module';
import { UserModule } from './apis/user/user.module';
import { PointTransactionModule } from './apis/pointTransaction/pointTransaction.module';
import { PaymentModule } from './apis/payment/payment.module';
// import { Product } from './apis/product/entities/product.entity';
// import { Board } from './apis/board/entities/board.entity';
// import { ProductSalesLocation } from './apis/productSalesLocation/entities/productSalesLocation.entity';

@Module({
  imports: [
    PaymentModule,
    PointTransactionModule,
    AuthModule,
    UserModule,
    SubCategoryModule,
    ProductModule,
    // ConfigModule.forRoot({ isGlobal: true }),
    GraphQLModule.forRoot({
      driver: ApolloDriver,
      autoSchemaFile: 'src/common/graphql/schema.gql',
      context: ({ req, res }) => ({ req, res }),
    }),
    TypeOrmModule.forRoot({
      type: 'mysql',
      host: 'localhost',
      port: 3306,
      username: 'root',
      password: '072865as!',
      database: 'homework',
      entities: [__dirname + '/apis/**/*.entity.*'], // apis폴더안에 존재하는 모든 폴더를 또뒤져서 .entity라는 파일을 가져오는데 확장자가 어떤것이든 다가져온다
      // entities: [Product],
      //__dirname 은 현재경로를 뜻하는것
      synchronize: true,
      logging: true,
    }),
  ],
  // controllers: [AppController],
  // providers: [AppService],
})
export class AppModule {}
