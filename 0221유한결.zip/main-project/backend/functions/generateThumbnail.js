exports.helloGCS = (event, context) => {
  const { Storage } = require('@google-cloud/storage');
  const sharp = require('sharp');

  const size = [
    ['s', 320],
    ['m', 640],
    ['l', 1280],
  ];
  if (event.name.includes('thumb')) return;

  const storage = new Storage();

  await Promise.all(
    size.forEach((el) => {
      return new Promise(() => {
        storage
          .bucket('hangyeolyu')
          .file(event.name)
          .createReadStream()
          .pipe(sharp().resize({ width: el[1] }))
          .pipe(
            storage
              .bucket('hangyeolyu')
              .file(`thumb/${el[0]}/@thumb${event.name}`)
              .createWriteStream(),
          )
          .on('finish', () => console.log('성공'));
      });
    }),
  );
};
